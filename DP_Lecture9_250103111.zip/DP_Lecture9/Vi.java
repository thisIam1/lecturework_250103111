package DP_Lecture9;

interface Video {
    void play();
}

class RealVideo implements Video {
    private String fileName;

    public RealVideo(String fileName) {
        this.fileName = fileName;
        downloadVideo();
    }

    private void downloadVideo() {
        System.out.println("--> [DOWNLOADING] Connecting to server & buffering 4K video: " + fileName);
    }

    @Override
    public void play() {
        System.out.println("Playing video: " + fileName);
    }
}

class ProxyVideo implements Video {
    private RealVideo realVideo;
    private String fileName;
    private int viewCount = 0;

    public ProxyVideo(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void play() {
        viewCount++;
        System.out.println("--> [AUDIT] Video has been played " + viewCount + " time(s).");

        if (realVideo == null) {
            realVideo = new RealVideo(fileName);
        }
        realVideo.play();
    }
}

public class Vi {
    public static void main(String[] args) {
        Video video = new ProxyVideo("Cat_Memes.mp4");

        video.play();
        System.out.println();
        video.play();
        System.out.println();
        video.play();
    }
}
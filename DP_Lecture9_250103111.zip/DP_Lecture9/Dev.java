package DP_Lecture9;

interface Device{
    void turnOn();
    void turnOff();
    void setVolume(int level);
}
// 1 dev
class Radio implements Device{
    @Override
    public void turnOn(){
        System.out.println("Radio starts playing static/music");
    }

    @Override
    public void turnOff(){
        System.out.println("Radio turned off");
    }

    @Override
    public void setVolume(int level) {
        System.out.println("Radio volumeknob turned to:" + level);
    }
}
// 2 dev
class SmartLight implements Device{
    @Override
    public void turnOn() {
        System.out.println("Smart Lightglows bright  white");
    }
    @Override
    public void turnOff(){
        System.out.println("Smart Light shuts off  ");
    }
    @Override
    public void setVolume(int level){
        System.out.println("Smart lightbrightness set to:  " + level + " %");
    }
}

class BasicRemote{
    protected Device device;

    public BasicRemote(Device device){
        this.device = device;
    }

    public void powerOn(){
        device.turnOn();
    }

    public void powerOff(){
        device.turnOff();
    }
}

class AdvancedRemote extends BasicRemote{
    public AdvancedRemote(Device device){
        super(device);
    }
    public void mute(){
        System.out.println("Mute button have pressed!");
        device.setVolume(0);
    }
}

public class Dev{
    public static void main(String[] args){
//        Device light = new SmartLight();
//        AdvancedRemote remote = new AdvancedRemote(light);
//
//        remote.powerOn();
//        remote.mute();

        Device radio = new Radio();
        PartyRemote partyRemote = new PartyRemote(radio);

        partyRemote.partyMode();
    }
}
